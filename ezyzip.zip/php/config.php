<?php 
 
 $con = mysqli_connect("localhost","root","","dentalclinic") or die("Couldn't connect");

?>